
source("functions.R")

N=100000 #200000
rho=0.5 #0.2;0.8
case=1 #2 
S=200
error.type=1 #2;3;4

nmachine = c( 50,100,200,500)
AEE = matrix(,length(nmachine),4) 
AEESD = matrix(,length(nmachine),4) 
ACT = matrix(,length(nmachine),2)
ACTSD = matrix(,length(nmachine),2)

for (k in 1:length(nmachine)) {
  cores <- detectCores()-2
  cl <- makeCluster(cores)
  registerDoParallel(cl, cores=cores)
  sim.res = foreach(i=1:S, .packages =c("matrixStats", "MASS", "glmnet","Runuran")) %dopar%
    {
      n=N/nmachine[k]
      Data = DGPfunB(N=N, rho=rho, n=n, case=case,error.type)
      X = Data$X
      Y = Data$Y
      beta = Data$beta
      
      fit.glpre = glpre(X, Y)
      glpre_beta = fit.glpre$beta
      time_glpre = fit.glpre$running_time
      ee_g = norm(glpre_beta-beta, "2")
      
      fit.clpre = clpre(X, Y, nmachine=nmachine[k], B=1)
      clpre_beta = fit.clpre$beta
      time_clpre = fit.clpre$running_time
      ee_c = norm(clpre_beta-beta, "2")
      
      cls_beta = csl.ls(X, log(Y), nmachine=nmachine[k], B=1)$beta
      ee_cls = norm(cls_beta-beta, "2")
      
      alpre_beta = alpre(X, Y, nmachine=nmachine[k])$beta
      ee_a = norm(alpre_beta-beta, "2")
      
      ee=c(ee_g, ee_c, ee_a, ee_cls )
      running_time = c(time_glpre, time_clpre)
      
      names(ee) = c("GLPRE", "CLPRE", "ALPRE","CLS")
      names(running_time) = c("GLPRE", "CLPRE")
      
      return(list(EE=ee, Running_time=running_time))
      
    }    #����֮��õ�һ��S*(3)�ľ���
  stopImplicitCluster()
  stopCluster(cl)#��ֹ����
  ee <- runningtime <- list()
  for (j in 1:S) {
    ee[[j]] <- sim.res[[j]]$EE
    runningtime[[j]] <- sim.res[[j]]$Running_time
  }
  ee_matrix <- do.call(rbind, ee)
  aee <- colMeans(ee_matrix)
  aee_sd <- colSds(ee_matrix)
  act <- colMeans(do.call(rbind, runningtime))
  act_sd <- colSds(do.call(rbind, runningtime))
  
  AEE[k,] = aee
  AEESD[k,] = aee_sd
  ACT[k, ] = act
  ACTSD[k, ] = act_sd
  
}
colnames(AEE) = colnames(AEESD)  = c( "GLPRE", "CLPRE", "ALPRE","CLS")
colnames(ACT) =colnames(ACTSD) = c( "GLPRE", "CLPRE")
AEE
AEESD
ACT
ACTSD



