
source("functions.R")

N = 100000 #N=20000
rho = 0.5 #0.2;0.8
S = 200
case = 1 #2
error.type=1 #2;3;4


nmachine = c(50,100,200,500)

AEE = AMS = ACF = matrix(,length(nmachine),4) 
AEESD = AMSSD = ACFSD = matrix(,length(nmachine),4) 
ACT = matrix(,length(nmachine),2)
ACTSD = matrix(,length(nmachine),2)

for(m in 1:length(nmachine)){
  
  cores <- detectCores()-2
  cl <- makeCluster(cores)
  registerDoParallel(cl, cores=cores)
  sim.res <- foreach(aa=1:S, .packages =c("matrixStats", "MASS", "glmnet","Runuran")) %dopar%
    {
      n = N/nmachine[m]
      dat = DGPfunD(N=N, rho=rho, n=n, case=case, error.type)
      X = dat$X
      Y = dat$Y
      beta = dat$beta
      
      lambda_max<-max(abs(t(X)%*%log(Y))/N)
      lambda_min<-lambda_max * 1e-3
      lambda1<-seq(log(lambda_max), log(lambda_min), length=50)
      lambda<-exp(lambda1)
      
      fit_pglpre = pglpre(X, Y, lambda=lambda)
      t_pglpre_1 = proc.time()
      pglpre_beta = fit_pglpre$beta[, which.min(fit_pglpre$dbic)]
      t_pglpre_2 = proc.time()
      t_pglpre = t_pglpre_2[3]-t_pglpre_1[3] +fit_pglpre$running_time
      
      fit_pcsl = pcsl.ls(X, log(Y), lambda=lambda, nmachine=nmachine[m])
      pcls_beta = fit_pcsl$beta[, which.min(fit_pcsl$dbic)]
      
      palpre_beta = palpre(X, Y, lambda=lambda, nmachine=nmachine[m])$beta
      
      fit_pclpre = pclpre(X, Y, lambda=lambda, nmachine=nmachine[m])
      t_pclpre_1 = proc.time()
      pclpre_beta = fit_pclpre$beta[, which.min(fit_pclpre$dbic)]
      t_pclpre_2 = proc.time()
      t_pclpre = t_pclpre_2[3]-t_pclpre_1[3] +fit_pclpre$running_time
      
      ee = c(norm(pglpre_beta-beta, "2"), norm(pclpre_beta-beta,"2"),
             norm(palpre_beta-beta, "2"), norm(pcls_beta-beta,"2")  )
      #ee
      ms = c(sum(pglpre_beta!=0), sum(pclpre_beta!=0), 
             sum(palpre_beta!=0), sum(pcls_beta!=0) )
      
      poi = which(beta!=0)
      fp = c(sum(pglpre_beta[-poi]!=0),sum(pclpre_beta[-poi]!=0),sum(palpre_beta[-poi]!=0),
             sum(pcls_beta[-poi]!=0))/sum(beta==0)
      fn = c(sum(sum(pglpre_beta[poi]==0),pclpre_beta[poi]==0), sum(palpre_beta[poi]==0),
             sum(pcls_beta[poi]==0) )/sum(beta!=0)
      
      cf = (fp + fn==0)
      Running_time = c( t_pglpre,t_pclpre)
      
      
      names(ee) = names(ms) =  names(cf)  = c("GPLPRE", "CPLPRE", "APLPRE", "CPLS")
      names(Running_time) = c( "GPLPRE", "CPLPRE")
      
      return(list(EE=ee, MS=ms, CF=cf, CT=Running_time))
    }
  stopImplicitCluster()
  stopCluster(cl)
  ee <- ms <-  cf <- ct <-list()
  for (s in 1:length(sim.res)) {
    ee[[s]] <- sim.res[[s]]$EE 
    ms[[s]] <- sim.res[[s]]$MS
    cf[[s]] <- sim.res[[s]]$CF
  }
  EE <- do.call(rbind, ee)
  AEE[m,] <- colMeans(EE)
  AEESD[m,] <- colSds(EE)
  
  MS <- do.call(rbind, ms)
  AMS[m,] <- colMeans(MS)
  AMSSD[m,] <- colSds(MS)
  
  CF <- do.call(rbind, cf)
  ACF[m,] <- colMeans(do.call(rbind, cf))
  ACFSD[m,] <- colSds(apply(CF,2,as.numeric))
  
  cat("m=",m, " is done", "\n")
}

colnames(AEE) = colnames(AEESD) =c("GPLPRE", "CPLPRE", "APLPRE", "CPLS")
colnames(AMS) = colnames(AMSSD) = c("GPLPRE", "CPLPRE", "APLPRE", "CPLS")
colnames(ACF) = colnames(ACFSD) =c("GPLPRE", "CPLPRE", "APLPRE", "CPLS")
colnames(ACT) = colnames(ACTSD) = c( "GPLPRE", "CPLPRE")

AEE
AMS
AMS
AMS
