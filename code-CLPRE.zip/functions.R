
library(ggplot2)
library(ggpubr)
library(RColorBrewer)  
library(Runuran)
library(matrixStats)
library(doParallel) 
library(doSNOW)
library(foreach)
library(glmnet)
library(dfoptim)  
library(ggforce)

#global least squares estimator
gls <- function(x, y){
  x <- as.matrix(x)
  y <- as.vector(y)
  t1 <- proc.time()
  b.est <- coef(lm(y~x+0))
  t2 <- proc.time()
  return(list(beta=b.est,running_time=(t2-t1)[3]))
}

#global least product relative error estimator
glpre <- function(x, y){
  x <- as.matrix(x)
  y <- as.vector(y)
  n <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  t1 <- proc.time()
  par <- coef(lm(log(y)~x+0))
  t2 <- proc.time()
  #par <- rep(0, ncol(x))#coef(lm(log(y)~x+0))
  b.est <- par+100 
  for(k in 1:1000){
    f <- tx %*% (yinv * exp(x %*% par) - y*exp(-x %*% par)) 
    tt <- yinv*exp(x %*% par)+y*exp(-x %*% par) 
    f_diff=tx %*% (x*c(tt)) 
    b.est <- par-solve(f_diff)%*%f
    if(norm(b.est - par,"2")<=1e-6) break
    par <- b.est
  }
  t3 <- proc.time()
  return(list(beta=b.est,running_time=(t3-t1)[3],(t2-t1)[3]))
}

#penalized global least product relative error estimator
pglpre <- function(x, y, lambda=NULL, gamma=1){
  N <- length(y)
  p <- ncol(x)
  t1 <- proc.time()
  beta.glpre <- glpre(x, y)$beta
  if(all(x[,1]==1)){ 
    intercept <- TRUE
    x <- x[, -1]
    beta.glpre <- beta.glpre[-1]
  }else{
    intercept <- FALSE
  }
  if(is.null(lambda)){
    lambda_max <- max(abs(t(x) %*% log(y))/N)
    lambda_min <- lambda_max * 1e-3
    lambda1 <- seq(log(lambda_max), log(lambda_min), length=50)
    lambda <- exp(lambda1)
  }
  
  w <- 1/abs(1/N+abs(beta.glpre))^gamma
  fit <- lpre.admm(x, y, lambda=lambda, intercept=intercept, 
                   normalize=FALSE, gamma = gamma, penalty.factor=w) 
  xx <- as.matrix(cbind(1, x))
  y <- as.vector(y)
  dbic <- log(colMeans((y - exp(xx%*%fit$beta))^2/(y*exp(xx%*%fit$beta)))) + fit$df*log(N)/N
  if(intercept){
    beta <- fit$beta
  }else{
    beta <- fit$beta[-1, ]
  }
  t2 <- proc.time()
  return(list(beta=beta, df=fit$df, lambda=fit$lambda, dbic=dbic,running_time=(t2-t1)[3]))
}

#average least product relative error estimator
alpre <- function(x, y, nmachine=2){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o <- 1:N
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  t1 <- proc.time()
  para <- sapply(1:nmachine, function(j){glpre(x[groups[[j]], ], y[groups[[j]]])$beta})
  t2 <- proc.time()
  b.est <- rowMeans(para)
  t3 <- proc.time()
  running.time <-(t2-t1)[3]/nmachine + (t3-t2)[3]
  return(list(beta=b.est,running_time=running.time))
}

#penalized average least product relative error estimator
palpre <- function(x, y, lambda=NULL, nmachine=2, gamma=1){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o <- 1:N
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  t.start=proc.time()
  if(is.null(lambda)){
    lambda_max <- max(abs(t(x) %*% log(y))/N)
    lambda_min <- lambda_max * 1e-3
    lambda1 <- seq(log(lambda_max), log(lambda_min), length=50)
    lambda <- exp(lambda1)
  }
  t1=proc.time()
  para <- sapply(1:nmachine, function(j){
          fit <- pglpre(x[groups[[j]], ], y[groups[[j]]], lambda = lambda, gamma = gamma)
          fit$beta[, which.min(fit$dbic)]})
  t2=proc.time()
  time1=(t2-t1)[3]/nmachine
  beta <- rowMeans(para)
  df <- length(which(beta!=0))
  t.end=proc.time()
  running.time <- (t.end-t.start)[3] - (nmachine-1)*time1 
  return(list(beta=beta, df=df, lambda=lambda,running_time=running.time))
}

#CSL estimator based on least squares loss
csl.ls <- function(x, y, nmachine, B=1){
  ##Method 2
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o <- 1:N
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- -txj %*% (y[groups[[j]]] - x[groups[[j]], ] %*% par)  
    fj
  }
  
  ## Calculate the initial estimate for the first machine
  t.start <- proc.time()
  #par <- gls(x1, y1)$beta 
  als <- sapply(1:nmachine, function(j){gls(x[groups[[j]], ], y[groups[[j]]])$beta})
  t1 <- proc.time()
  t_par = (t1-t.start)[3]/nmachine
  par <- rowMeans(als)
  time1 <- 0
  for (b in 1:B) {
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f1 <- cd(1)
    f <- rowMeans(para)
    f_diff1 <-  tx[, groups[[1]]] %*% x[groups[[1]], ]
    b.est <- par - solve(f_diff1) %*% f 
    par <- b.est
  }
  t.end <- proc.time()
  running.time <- (t.end-t.start)[3] - (nmachine-1)*time1 - (nmachine-1)*t_par
  return(list(beta=b.est, running_time=running.time))
}

#penalized CSL estimator based on least squares loss
pcsl.ls <- function(x, y, lambda=NULL, nmachine=2, B=1, gamma=1){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  tx <- t(x)
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o <- 1:N
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- -txj %*% (y[groups[[j]]] - x[groups[[j]], ] %*% par)  
    fj
  }
  
  x1 <- x[groups[[1]], ]
  y1 <- y[groups[[1]]]
  tx1 <- tx[, groups[[1]]] 
  
  #Approximation algorithm to solve beta (SQP)
  solvels <- function(a, u, rho){
    D1 <- -tx1 %*% y1/n - para[, 1]/n + f/N
    D2 <- tx1 %*% x1/n
    # SVD <- svd(D2+diag(rho, p))
    # D.inverse <- SVD$v%*%diag(1/SVD$d)%*%t(SVD$u)
    D.inverse <- solve(D2+diag(rho, p))
    q <- rho * a - u - D1
    beta <- D.inverse %*% q
    return(beta)
  }
  
  ##solve penlity lpre function 
  penls <- function(lambdaj){
    rho <- 1#; alpha <- 1.8
    ak <- par
    uk <- rep(0,p)
    w <- lambdaj/(1/n + abs(par))^gamma
    if(all(x[, 1]==1)){ w[1] <- 0}
    maxiter <- 300
    eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
    for (k in 1 : maxiter) {
      bnew <- solvels(ak, uk, rho)
      #bnew <- alpha * bnew + (1 - alpha) * ak
      s <- bnew + uk/rho
      anew <- sign(s)*pmax(abs(s)-w/rho, 0)
      unew <- uk + rho * (bnew -anew)   
      
      if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
         norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
      
      ak <- anew
      uk <- unew
    }
    return(c(k, length(which(anew!=0)), anew))
  }
  
  ## Calculate the initial estimate for the first machine
  #par <- gls(x1, y1)$beta 
  t.start <- proc.time()
  als <- sapply(1:nmachine, function(j){gls(x[groups[[j]], ], y[groups[[j]]])$beta})
  t1 <- proc.time()
  t_par = (t1-t.start)[3]/nmachine
  par <- rowMeans(als)
  time1 <- 0
  if(length(lambda)!=1){B <- 1}
  for(b in 1:B){
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f <- rowMeans(para)
    f1 <- cd(1)
    res <- sapply(1:length(lambda), function(j){penls(lambda[j])})
    iter <- res[1, ]
    df <- res[2, ]
    beta <- res[-c(1,2), ]
    par <- beta
  }
  dbic <- log(colMeans((y1 - x1%*%beta)^2)-t(beta)%*%(f1/n-f/N)
              +t(par)%*%(f1/n-f/N)-colMeans((y1 - x1%*%par)^2)
              +colMeans((y - x%*%par)^2))+df*log(N)/N
  t.end <- proc.time()
  running.time <- (t.end-t.start)[3] -(nmachine-1)*time1 -(nmachine-1)*t_par
  return(list(beta=beta, df=df, lambda=lambda, dbic=dbic,running_time=running.time))
}

#CSL estimator based on least product relative error loss 
clpre <- function(x, y, nmachine=2, B=1){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o <- 1:N
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- txj %*% (yinv[groups[[j]]] * exp(x[groups[[j]], ] %*% par) 
                   - y[groups[[j]]]*exp(-x[groups[[j]], ] %*% par)) 
    fj
  }
  
  x1 <- x[groups[[1]], ]
  y1 <- y[groups[[1]]]
  tx1 <- tx[, groups[[1]]] 
  yinv1 <- yinv[groups[[1]]]
  
  ## Calculate the initial estimate for the first machine
  t.start <- proc.time()
  #par <- glpre(x1, y1)$beta
  par_sum <- sapply(1:nmachine, function(j){glpre(x[groups[[j]], ], y[groups[[j]]])$beta})
  t1 <- proc.time()
  t_par = (t1-t.start)[3]/nmachine
  par <- rowMeans(par_sum)
  time1 <- 0
  for(b in 1:B){
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f <- rowMeans(para) 
    for (e in 1:1000) {
      f1 <- cd(1) 
      d1 <- yinv1*exp(x1 %*% par) + y1*exp(-x1 %*% par)
      f_diff1 <-  tx1 %*% ( x1*c(d1))
      b.est <- par - solve(f_diff1) %*% (f1 - para[, 1] + f)
      if(norm(b.est-par,"2") < 1e-6) break
      par <- b.est
    }
  }
  t.end <- proc.time()
  running.time <- (t.end-t.start)[3] - (nmachine-1)*time1 - (nmachine-1)*t_par
  return(list(beta=b.est,running_time=running.time ))
}

#penalized CSL estimator based on least product relative error loss (our method)
pclpre <- function(x, y, lambda=NULL, nmachine=2, B=1, gamma=1){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o <- 1:N
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- txj %*% (yinv[groups[[j]]] * exp(x[groups[[j]], ] %*% par) 
                   - y[groups[[j]]]*exp(-x[groups[[j]], ] %*% par)) 
    fj
  }
  
  x1 <- x[groups[[1]], ]
  y1 <- y[groups[[1]]]
  tx1 <- tx[, groups[[1]]] 
  yinv1 <- yinv[groups[[1]]]
  
  solvelpre <- function(a, b, u, rho){
    D1 <- tx1 %*% (yinv1*exp(x1 %*% b) - y1*exp(-x1 %*% b))/n - para[, 1]/n + f/N
    tt <- yinv1*exp(x1 %*% b) + y1*exp(-x1 %*% b)
    D2=tx1 %*% (x1*c(tt))/n 
    D.inverse <- solve(D2+diag(rho, p))
    q <- rho * a - u + D2 %*% b - D1
    beta <- D.inverse %*% q
    return(beta)
  }
  
  ##solve penlity lpre function 
  penlpre <- function(lambdaj){
    rho <- 1#; alpha <- 1.8
    ak <- uk <- rep(0,p)
    bk <- par
    w <- lambdaj/(1/n + abs(par))^gamma  
    if(all(x[, 1]==1)) {w[1] <- 0}
    maxiter <- 300
    eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
    for (k in 1 : maxiter) {
      bnew <- solvelpre(ak, bk, uk, rho)
      #bnew <- alpha * bnew + (1 - alpha) * ak
      s <- bnew + uk/rho
      anew <- sign(s)*pmax(abs(s)-w/rho, 0)  
      unew <- uk + rho * (bnew -anew)   
      
      if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
         norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
      #if(norm(bnew-ak,"2")<eps2&&norm(anew-ak,"2")<eps2) break
      
      bk <- bnew
      ak <- anew
      uk <- unew
    }
    return(c(k, length(which(anew!=0)), anew))
  }
  
  ## Calculate the initial estimate for the first machine
  t.start <- proc.time()
  #par <- glpre(x1, y1)$beta
  par_sum <- sapply(1:nmachine, function(j){glpre(x[groups[[j]], ], y[groups[[j]]])$beta})
  t1 <- proc.time()
  t_par = (t1-t.start)[3]/nmachine
  par <- rowMeans(par_sum)
  time1 <- 0
  if(length(lambda)!=1){B <- 1}
  for(b in 1:B){
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f <- rowMeans(para)
    f1 <- cd(1)
    res <- sapply(1:length(lambda), function(j){penlpre(lambda[j])})
    iter <- res[1, ]
    df <- res[2, ]
    beta <- res[-c(1,2), ]
    par <- beta
  }
  y1 <- as.vector(y1)
  dbic <- log(colMeans((y1 - exp(x1%*%beta))^2/(y1*exp(x1%*%beta)))-t(beta)%*%(f1/n-f/N)
              +t(par)%*%(f1/n-f/N)-colMeans((y1 - exp(x1%*%par))^2/(y1*exp(x1%*%par)))
              +colMeans((y - exp(x%*%par))^2/(y*exp(x%*%par))))+df*log(N)/N
  t.end <- proc.time()
  running.time <- (t.end-t.start)[3] -(nmachine-1)*time1 -(nmachine-1)*t_par
  return(list(beta=beta, df=df, lambda=lambda, dbic=dbic,running_time=running.time))
}

#ADMM algorithm for pglpre
lpre.admm <- function(x, y, lambda=NULL, intercept=FALSE, normalize=FALSE, 
                   gamma=0, penalty.factor=rep(1, ncol(x))){
  x <- as.matrix(x)
  y <- as.matrix(y)
  np <- dim(x)
  n <- np[1]
  p <- np[2]
  
  if(intercept){
    meanx <- colMeans(x)
    #mprody <- mean(abs(y))*prod(y/mean(abs(y)))^(1/n) 
    mprody <- max(abs(y))*prod(y/max(abs(y)))^(1/n) 
  }else{
    meanx <- rep(0, p)
    mprody <- 1
  }
  x <- scale(x, meanx, FALSE) 
  if(normalize){normx <- sqrt(colSums(x^2)) }else{ normx <- rep(1, p)}
  x <- scale(x, FALSE, normx)
  y <- y/mprody 
  tx <- t(x)
  
  if(is.null(lambda)) {
    lambda_max<-max(abs(tx%*%log(y))/n)
    lambda_min<-lambda_max * 1e-3
    lambda1<-seq(log(lambda_max), log(lambda_min), length=50)
    lambda<-exp(lambda1)
  } 
  
  #Approximation algorithm to solve beta (SQP)
  solvelpre <- function(a, b, u, rho){
    D1 <- tx %*% (1/y*exp(x %*% b) - y*exp(-x %*% b))/n 
    tt <- 1/y*exp(x %*% b) + y*exp(-x %*% b)
    D2 <- tx %*% ( x*c(tt))/n  
    D.inverse <- solve(D2+diag(rho, p))
    q <- rho * a - u + D2 %*% b - D1
    beta <- D.inverse %*% q
    return(beta)
  }
  
 
  ##solve penlity lpre function 
  penlpre <- function(lambdaj){
    rho <- 1#; alpha <- 1.8
    ak <- bk <- uk <- rep(0,p)
    w <- lambdaj*penalty.factor^gamma
    if(n > p) bk <- lm(log(y) ~ x + 0)$coef 
    maxiter <- 300
    eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
    for (k in 1 : maxiter) {
      bnew <- solvelpre(ak, bk, uk, rho)
      #bnew <- alpha * bnew + (1 - alpha) * ak
      s <- bnew + uk/rho
      anew <- sign(s)*pmax(abs(s)-w/rho, 0)
      unew <- uk + rho * (bnew -anew)   
      
      if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
         norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
      #if(norm(bnew-ak,"2")<eps2&&norm(anew-ak,"2")<eps2) break
      
      bk <- bnew
      ak <- anew
      uk <- unew
    }
    return(c(k, length(which(anew!=0)), anew))
  }

  para <- sapply(1:length(lambda), function(j){penlpre(lambda[j])})
  iter <- para[1, ]
  df <- para[2, ]
  b <- scale(t(para[-c(1,2), ]), FALSE, normx)
  esti <- rbind(log(mprody) - meanx %*% t(b), t(b))
  
  return(list(beta=esti, lambda=lambda, df=df, iter=iter))
}



DGPfunB <- function(N, rho, n, case, error.type){
  if(case==1){
    p = max((floor(4*n^{1/4})-5), 4) 
    if(p%%2 ==0){
      beta = rep(c(1,1.5),p/2)
    }else{
      beta = c(rep(c(1,1.5),(p-1)/2),1)}#beta=c(1,1.5,1,1.5,����,1,1.5)
  }else{
    p = max((floor(10*n^{1/4})-5), 4)
    if(p%%2 ==0){
      beta = rep(c(1,1.5),p/2)
    }else{
      beta = c(rep(c(1,1.5),(p-1)/2),1)}
  }
  xx =  matrix(rnorm(N*p), N, p)
  
  if(rho==0){
    X=xx
  }else{
    corrmat = toeplitz(rho^(0:(p-1)))
    cholmat = chol(corrmat)            #chol(A) = A'A
    X = xx %*% cholmat
  }
  
  lpdf1 = function(x){ -x-1/x-log(x)+2 }              
  gen1 = ars.new(logpdf=lpdf1, lb=0.0000001, ub=Inf)
  f = function(x){ (1/2)*x^2-(1/2)*0.25-log(x)+log(0.5) }
  uni = uniroot(f, c(0.51,2))$root
  epsilon = switch(error.type, ur(gen1, N), rlnorm(N), exp(runif(N, -2, 2)), runif(N, 0.5, uni))
  Y = exp(X%*%beta)*epsilon
  return(list(Y=Y, X=X, beta=beta))
}


DGPfunD <- function(N, rho, n, case, error.type){
  if(case==1){
    p = max((floor(4*n^{1/4})-5), 6); beta = c(2,1,1.5,0.8,0.5,rep(0,p-5))#c=2
  }else{
    p = max((floor(10*n^{1/4})-5), 6); beta = c(2,1,1.5,0.8,0.5,rep(0,p-5))#c=4
  }
  xx =  matrix(rnorm(N*p), N, p)
  
  if(rho==0){
    X=xx
  }else{
    corrmat = toeplitz(rho^(0:(p-1)))
    cholmat = chol(corrmat)            #chol(A) = A'A
    X = xx %*% cholmat
  }
  
  lpdf1 = function(x){ -x-1/x-log(x)+2 }              
  gen1 = ars.new(logpdf=lpdf1, lb=0.0000001, ub=Inf)
  f = function(x){ (1/2)*x^2-(1/2)*0.25-log(x)+log(0.5) }
  uni = uniroot(f, c(0.51,2))$root
  epsilon = switch(error.type, ur(gen1, N), rlnorm(N), exp(runif(N, -2, 2)), runif(N, 0.5, uni))

  Y = exp(X%*%beta)*epsilon
  return(list(Y=Y, X=X, beta=beta))
}

