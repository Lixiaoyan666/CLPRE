# CLPRE estimator

Relative error-based distributed estimation in growing dimensions

Paper: Li X., Xia X. and Zhang Z. (2024+). Relative error-based distributed estimation in growing dimensions. Submit to journal.


